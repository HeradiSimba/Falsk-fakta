
import React, { useState } from 'react';
import QRCode from 'qrcode.react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

const questions = [
  {
    question: "I Sverige är det olagligt att döpa en gris till ___",
    correctAnswer: "Kungen"
  },
  {
    question: "År 1993 förbjöds det i Sverige att använda ___ i reklamfilmer.",
    correctAnswer: "barn under 12 år"
  }
];

export default function Game() {
  const [players, setPlayers] = useState([]);
  const [scores, setScores] = useState({});
  const [name, setName] = useState('');
  const [joined, setJoined] = useState(false);
  const [currentRound, setCurrentRound] = useState(0);
  const [bluffs, setBluffs] = useState({});
  const [guesses, setGuesses] = useState({});
  const [stage, setStage] = useState('start'); // start, join, bluff, guess, result
  const [host, setHost] = useState(false);

  const joinGame = () => {
    if (name && !players.includes(name)) {
      setPlayers([...players, name]);
      setScores({ ...scores, [name]: 0 });
      setJoined(true);
    }
  };

  const submitBluff = (bluff) => {
    setBluffs({ ...bluffs, [name]: bluff });
    if (Object.keys(bluffs).length + 1 === players.length) {
      setStage('guess');
    }
  };

  const submitGuess = (guess) => {
    const newGuesses = { ...guesses, [name]: guess };
    setGuesses(newGuesses);
    if (Object.keys(newGuesses).length + 1 === players.length) {
      let newScores = { ...scores };
      for (const player of players) {
        if (newGuesses[player] === questions[currentRound % questions.length].correctAnswer) {
          newScores[player] += 1;
        }
        for (const [bluffAuthor, bluffAnswer] of Object.entries(bluffs)) {
          if (newGuesses[player] === bluffAnswer && bluffAuthor !== player) {
            newScores[bluffAuthor] += 2;
          }
        }
      }
      setScores(newScores);
      setStage('result');
    }
  };

  const resetRound = () => {
    setBluffs({});
    setGuesses({});
    setCurrentRound(currentRound + 1);
    setStage('bluff');
  };

  const currentQuestion = questions[currentRound % questions.length];
  const allAnswers = [...Object.values(bluffs), currentQuestion.correctAnswer].sort(() => Math.random() - 0.5);
  const highestScore = Math.max(...Object.values(scores));
  const leaders = players.filter((p) => scores[p] === highestScore);
  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Falsk Fakta</h1>

      {stage === 'start' && (
        <div className="space-y-4">
          <Input placeholder="Skriv ditt namn" value={name} onChange={(e) => setName(e.target.value)} />
          <Button onClick={() => { setJoined(true); setHost(true); setPlayers([name]); setScores({ [name]: 0 }); setStage('join'); }}>Starta nytt spel</Button>
          <Button onClick={() => { setJoined(true); setStage('join'); }}>Gå med i spel</Button>
        </div>
      )}

      {joined && stage === 'join' && (
        <div className="space-y-4 mt-6">
          <p>Du är med i spelet som: <strong>{name}</strong></p>
          <div>
            <h2 className="font-semibold mb-2">Spelare i lobbyn:</h2>
            <ul className="list-disc list-inside">
              {players.map((player) => (
                <li key={player}>{player} – {scores[player] ?? 0} poäng</li>
              ))}
            </ul>
          </div>
          {leaders.length > 0 && (
            <p className="mt-2">Ledare: <strong>{leaders.join(', ')}</strong> med {highestScore} poäng</p>
          )}
          {host && (
            <div className="mt-4">
              <h3 className="font-semibold mb-2">Dela denna QR-kod:</h3>
              <QRCode value={currentUrl} size={128} />
              <p className="text-sm mt-2">Scanna för att gå med i spelet</p>
            </div>
          )}
          {!players.includes(name) && (
            <Button onClick={joinGame}>Gå med i spelet</Button>
          )}
          {host && players.length > 1 && (
            <Button onClick={() => setStage('bluff')}>Starta spelet</Button>
          )}
        </div>
      )}

      {joined && stage === 'bluff' && (
        <Card className="mt-6">
          <CardContent className="p-4">
            <h2 className="text-xl mb-2">{currentQuestion.question}</h2>
            <Input placeholder="Skriv ditt bluff-svar här" onBlur={(e) => submitBluff(e.target.value)} />
          </CardContent>
        </Card>
      )}

      {joined && stage === 'guess' && (
        <Card className="mt-6">
          <CardContent className="p-4">
            <h2 className="text-xl mb-4">{currentQuestion.question}</h2>
            <div className="space-y-2">
              {allAnswers.map((a, i) => (
                <Button key={i} className="w-full" onClick={() => submitGuess(a)}>
                  {a}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {joined && stage === 'result' && (
        <div className="mt-6 space-y-4">
          <h2 className="text-xl font-semibold">Resultat</h2>
          <p>Rätt svar: <strong>{currentQuestion.correctAnswer}</strong></p>
          <div>
            {Object.entries(guesses).map(([player, answer]) => (
              <p key={player}>{player} gissade: {answer}</p>
            ))}
          </div>
          <div className="mt-4">
            <h3 className="font-semibold">Poängställning:</h3>
            <ul className="list-disc list-inside">
              {players.map((player) => (
                <li key={player}>{player} – {scores[player] ?? 0} poäng</li>
              ))}
            </ul>
            {leaders.length > 0 && (
              <p className="mt-2">Ledare: <strong>{leaders.join(', ')}</strong> med {highestScore} poäng</p>
            )}
          </div>
          {host && <Button onClick={resetRound}>Nästa fråga</Button>}
        </div>
      )}
    </div>
  );
}
