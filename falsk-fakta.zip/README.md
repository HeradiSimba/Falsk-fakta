# Falsk Fakta – Svensk version av Fibbage 🎭

Ett flerspelarspel där du lurar dina vänner med falska svar och försöker gissa det riktiga!

## 🕹 Funktioner

- Skapa och gå med i spel
- Skriv bluffar, gissa rätt svar
- Poängräkning och ledarstatus
- QR-kod för att enkelt bjuda in spelare

## 🚀 Starta lokalt

```bash
npm install
npm run dev
```

## 🌍 Publicera

Publicera enkelt via [Vercel](https://vercel.com) eller annan React-host.

## 📱 Dela spelet

Använd QR-koden som genereras i lobbyn för att bjuda in andra!
